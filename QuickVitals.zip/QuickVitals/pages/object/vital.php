<?php
$connect = mysqli_connect('localhost','root', '', 'qv_public') or die('Database error!');

if(!isset($_GET['function'])){
		die('Some error occured');
}

function GetProducts($db){
   $sql = mysqli_query($db, 'SELECT * FROM `hospital');
   $data = array();
           $data [] = 'Hospital';
   if(mysqli_num_rows($sql) > 0){
	   while($row = mysqli_fetch_array($sql)){
		   $data [] = $row['id'];
		   $data [] = $row['name'];
		   $data [] = $row['email'];
		   $data [] = $row['password'];
		   $data [] = $row['contact'];
	   }
   }
   
   $sql = mysqli_query($db, 'SELECT * FROM `hospital');
           $data [] = 'User';
   if(mysqli_num_rows($sql) > 0){
	   while($row = mysqli_fetch_array($sql)){
		   $data [] = $row['id'];
		   $data [] = $row['email'];
		   $data [] = $row['password'];
		   $data [] = $row['firstname'];
		   $data [] = $row['middlename'];
		   $data [] = $row['lastname'];
		   $data [] = $row['dateofbirth'];
		   $data [] = $row['gender'];
		   $data [] = $row['address'];
		   $data [] = $row['contact'];
		   $data [] = $row['emergencyname'];
		   $data [] = $row['emergencycontact'];
		   $data [] = $row['emergencyrelationship'];
		   $data [] = $row['medicare'];
		   $data [] = $row['address'];
		   $data [] = $row['contact'];
	   }
   }
}

?>