<?php
include_once 'header.php';
include_once 'sidebar.php';
include_once 'nav.php';
?>

        <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
            <div class="page-title">
              <div class="title_left">
              </div>
            </div>
            
            <div class="clearfix"></div>

            <div class="row">
              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Need Help?</h2>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                    <div class="col-xs-12 text-center">
                      <div class="profile_img">
                        <div id="crop-avatar">
                          <!-- Current avatar -->
						  <img class="img-responsive margin-auto" width="150" src="../img/support.png" alt="Avatar" title="Change the avatar">                          
                        </div>
                      </div><br><br>
                      <h3>CALL 18000000000</h3>
					</div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- /page content -->

<?php
include_once 'footer.php';
?>